#include <iostream>
#include <time.h>

using namespace std;

/* Cau1: Viết hàm nhập giá trị tự động cho mảng, các giá trị thuộc [100; 999], số lượng phần tử thuộc [30; 50].
*/
void initDataAuto1(int* a, int& n)
{
	n = rand() % (50 - 30 + 1) + 30;

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % (999 - 100 + 1) + 100;
	}
}

void printArr(int a[], int n)
{
	cout << "Number: " << n << endl;
	for (int i = 0; i < n; i++)
	{
		cout << a[i] << " ";
	}
	cout << endl;
};

/* Cau 2: Viết hàm nhập giá trị tự động tăng dần cho mảng, phần tử đầu tiên ≤ 130, các phần tử kề nhau không quá 15, các giá trị thuộc [100; 999], số lượng phần tử thuộc [30; 50].
*/
void initDataAuto2(int* a, int& n)
{
	n = rand() % (50 - 30 + 1) + 30;
	a[0] = rand() % (130 - 100 + 1) + 100;

	for (int i = 1; i < n; i++)
	{
		a[i] = a[i - 1] + rand() % (15 - 1 + 1) + 1;
	}
}


/*
	Viết hàm xuất mảng.
*/
/*
	Viết hàm tìm kiếm một phần tử trong mảng bằng tìm kiếm tuyến tính.
*/
/*
	Viết hàm tìm kiếm một phần tử trong mảng bằng tìm kiếm nhị phân.
*/
/*
	Viết hàm tìm kiếm một phần tử trong mảng bằng tìm kiếm nội suy.
*/
/*
	Viết hàm so sánh số lần thực hiện tìm kiếm cùng một giá trị cho 3 thuật toán tìm kiếm trên.
*/

int main(){
	srand(time(0));
	int* a = new int[100];
	int n = 0;

	initDataAuto1(a, n);
	cout << "Test 1: printArr" << endl;
	printArr(a, n);

	initDataAuto2(a, n);
	cout << "Test 2: printArr" << endl;
	printArr(a, n);

	return 0;
}