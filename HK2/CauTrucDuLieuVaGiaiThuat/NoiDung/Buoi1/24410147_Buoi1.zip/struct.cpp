#include <iostream>
using namespace std;

struct NhanVien
{
	
	int maNV;
	string hoTen;
	float luongCB;
};

int main()
{
	/*
		int
		float
		double
		
	*/
	
	return 0;	
}