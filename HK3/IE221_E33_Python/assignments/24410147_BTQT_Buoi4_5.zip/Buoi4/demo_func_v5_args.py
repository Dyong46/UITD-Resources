
def ham(*args):
    print(args)

if __name__ == "__main__":
    ham()
    ham(1, 2, 3)
    ham([123], 9, 'dsss', {'2', 5})