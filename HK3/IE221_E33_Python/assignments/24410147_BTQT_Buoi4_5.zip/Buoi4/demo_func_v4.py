
def ham(a, b=1):
    print('a = ', a)
    print('b = ', b)

if __name__ == '__main__':
    ham(2, 3)
    ham(5)