
# chu thich
def func():
    """viet mo ta ham"""
    print("Hello")

if __name__ == "__main__":
    func()
    print(func.__doc__)