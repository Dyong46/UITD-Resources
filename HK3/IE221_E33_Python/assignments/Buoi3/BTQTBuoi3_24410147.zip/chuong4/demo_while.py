# Nhap n. Neu a la am thi nhap lai

n = input("Nhap n: ")
while int(n) < 0:
    n = input("Nhap lai n: ")
